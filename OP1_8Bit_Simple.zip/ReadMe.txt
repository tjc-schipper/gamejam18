TEENAGE ENGINEERING OP-1 8-BIT WAVES PATCH PACK
-------------------------------------------------------------------------
This pack contains the following presets as a kind-of one-stop-shop for the simplest synth sounds you can get from the OP-1:

- 1/5 PULSE, 1/4 PULSE, 1/3 PULSE - These three have a pretty classic NES-esque sound. Snappy.

- SQUARE WAVE - A straight two-bit square wave. Loud and in your face.

- SAWTOOTH - A sharp buzz with character great for leads.

- SINE WAVE - The cleanest sine wave I could draw with the engine. Sounds soft and melodic.

- HARD, SOFT TRIANGLE WAVE - Not as harsh as a sawtooth, more up-front than a sine. These two are the same wavelength but two different resolutions. Hard has fewer steps giving it more grit, sounds great for bass lines. Soft is cleaner and sounds softer, good for accompaniment.

All patches have a preset delay effect and vibrato LFO set up but disabled by default. When these are turned on, it really starts sounding properly retro. Also, mess with the envelope settings to shape the waves into other simulated types of 8-Bit instruments and sounds!


HOW TO INSTALL
-------------------------------------------------------------------------
- Power on your OP-1 and connect the USB cable to your computer.
- Press SHIFT+COM and press the "3" key to access the OP-1's disk mode.
- Wait for yuor computer to connect to the OP-1 and show it as an abailable USB disk.
- Drag the "simple" folder from this ZIP into the "synth" folder on your OP-1.
- Press the "1" key on the OP-1 to disconnect disk mode. The OP-1 will reboot and install new patches. When it's finished, press any key and enjoy your new presets!

- Feel free to rename the "simple" folder to something else.
- If the patches fail to install, you may either have too many installed already or you may be connected to a faulty USB hub!


-------------------------------------------------------------------------
Assembled by Matt Laskowski, www.orianart.com, matt@orianart.com